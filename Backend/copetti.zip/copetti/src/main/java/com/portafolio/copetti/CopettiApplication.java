package com.portafolio.copetti;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CopettiApplication {

	public static void main(String[] args) {
		SpringApplication.run(CopettiApplication.class, args);
	}

}
