package com.portafolio.copetti;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CopettiApplicationTests {

	@Test
	void contextLoads() {
	}

}
